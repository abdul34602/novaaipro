
import React from 'react';
const Sidebar: React.FC = () => null; // Layout handled in App.tsx for responsiveness
export default Sidebar;
