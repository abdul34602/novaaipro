
export const API_URL = (import.meta as any).env?.VITE_API_URL || "http://localhost:3000";
